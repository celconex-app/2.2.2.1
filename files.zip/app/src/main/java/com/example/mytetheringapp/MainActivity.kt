package com.example.mytetheringapp

import android.content.Context
import android.net.ConnectivityManager
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val tetherButton = findViewById<Button>(R.id.btnTether)

        tetherButton.setOnClickListener {
            // Advertencia: Esto solo funciona en apps del sistema
            try {
                val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
                val method = connectivityManager.javaClass.getDeclaredMethod("setTethering", Boolean::class.javaPrimitiveType)
                method.isAccessible = true
                method.invoke(connectivityManager, true)
                Toast.makeText(this, "Tethering activado", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                // En la mayoría de los casos, esto lanzará una excepción por permisos
                Toast.makeText(this, "No se pudo activar el tethering: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }
}