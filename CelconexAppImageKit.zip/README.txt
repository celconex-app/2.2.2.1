Reemplaza 'AppDir/usr/bin/CelconexApp' con tu binario real.
Luego usa appimagetool para generar la AppImage.