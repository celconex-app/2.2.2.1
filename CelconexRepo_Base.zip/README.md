# 📡 Celconex

Celconex es una aplicación de escritorio para Windows que te permite **compartir tu conexión de datos móviles (SIM o eSIM)** con otro dispositivo de forma inalámbrica, autorizando con tu número de teléfono y controlando el acceso.

---

## 🚀 Características principales

- 📱 Autenticación con Firebase
- ✉️ Envío real de SMS con Twilio
- 📤 Compartición controlada de datos móviles
- 🔐 Código de autorización por número
- 🔔 Notificaciones en tiempo real
- 📦 Instalador y versión portable disponibles
- 🔄 Actualizaciones automáticas

---

## 📥 Descargar Celconex

[![Descargar Celconex](https://img.shields.io/badge/Descargar-Celconex-blue?style=for-the-badge)](https://arturoochoa06.github.io/celconex)

- 🔧 [CelconexInstaller.exe](https://arturoochoa06.github.io/celconex/CelconexInstaller.exe) — Instalador para Windows
- 📦 [CelconexPortable.zip](https://arturoochoa06.github.io/celconex/CelconexPortable.zip) — Versión portable

---

## 🧪 Modo de uso

### 1. Instala o ejecuta Celconex
- Puedes usar el instalador o versión portable

### 2. Selecciona modo:
- 📤 Modo Emisor: comparte tus datos
- 📥 Modo Receptor: solicita y utiliza los datos

### 3. Autoriza con tu número
- Recibirás un código por SMS con Twilio
- Acepta o rechaza la conexión

---

## 📸 Capturas

<img src="banner.png" width="100%" alt="Banner Celconex" />

---

## 📬 Soporte

- Correo: [soporte@celconex.com](mailto:soporte@celconex.com)
- Twitter: [@Celconex](https://twitter.com/Celconex)
- Instagram: [@CelconexApp](https://instagram.com/CelconexApp)
- Facebook: [Celconex](https://facebook.com/Celconex)

---

## 📲 Código QR para descarga rápida

<img src="qr_celconex_logo_texto.png" alt="QR Celconex" width="240px" />

---

## 📁 Repositorios relacionados

- [`celconex-app`](https://github.com/arturoochoa06/celconex-app): Código fuente principal
- [`celconex-web`](https://github.com/arturoochoa06/celconex-web): Sitio web y landing

---

© 2025 Celconex. Todos los derechos reservados.