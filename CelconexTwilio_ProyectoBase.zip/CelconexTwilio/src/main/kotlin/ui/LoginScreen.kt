
package ui

import androidx.compose.runtime.*
import androidx.compose.material.*
import logic.AuthManager

@Composable
fun LoginScreen() {
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var isLoggedIn by remember { mutableStateOf(false) }

    if (isLoggedIn) {
        DashboardScreen(username)
    } else {
        Column {
            Text("Iniciar Sesión - Celconex")
            TextField(value = username, onValueChange = { username = it }, label = { Text("Usuario") })
            TextField(value = password, onValueChange = { password = it }, label = { Text("Contraseña") })
            Button(onClick = {
                if (AuthManager.login(username, password)) {
                    isLoggedIn = true
                }
            }) {
                Text("Entrar")
            }
        }
    }
}
