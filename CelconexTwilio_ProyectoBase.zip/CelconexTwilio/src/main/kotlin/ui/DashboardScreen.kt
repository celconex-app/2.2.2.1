
package ui

import androidx.compose.runtime.*
import androidx.compose.material.*
import logic.DataShareManager

@Composable
fun DashboardScreen(username: String) {
    var phoneNumber by remember { mutableStateOf("") }

    Column {
        Text("Bienvenido, $username")
        Text("Compartir datos con otro número")
        TextField(
            value = phoneNumber,
            onValueChange = { phoneNumber = it },
            label = { Text("Número a compartir datos") }
        )
        Button(onClick = {
            DataShareManager.sendAuthorizationCode(phoneNumber)
        }) {
            Text("Enviar Solicitud")
        }
    }
}
