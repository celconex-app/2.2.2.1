
package logic

import com.twilio.Twilio
import com.twilio.rest.api.v2010.account.Message
import com.twilio.type.PhoneNumber

object SmsService {
    private const val ACCOUNT_SID = "TU_ACCOUNT_SID"
    private const val AUTH_TOKEN = "TU_AUTH_TOKEN"
    private const val FROM_NUMBER = "+1234567890" // Número Twilio

    init {
        Twilio.init(ACCOUNT_SID, AUTH_TOKEN)
    }

    fun sendSms(to: String, message: String) {
        try {
            Message.creator(
                PhoneNumber(to),
                PhoneNumber(FROM_NUMBER),
                message
            ).create()
            println("Mensaje enviado a $to")
        } catch (e: Exception) {
            println("Error al enviar SMS: ${'$'}{e.message}")
        }
    }
}
