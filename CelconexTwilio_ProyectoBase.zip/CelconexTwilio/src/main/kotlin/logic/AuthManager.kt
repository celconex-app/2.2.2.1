
package logic

object AuthManager {
    fun login(username: String, password: String): Boolean {
        return username.isNotEmpty() && password.isNotEmpty()
    }
}
