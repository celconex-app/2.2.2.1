
package logic

object DataShareManager {
    fun sendAuthorizationCode(phoneNumber: String) {
        val code = (100000..999999).random().toString()
        println("Enviando código $code a $phoneNumber")
        SmsService.sendSms(phoneNumber, "Código de autorización Celconex: $code")
    }

    fun acceptSharing() {
        println("Conexión de datos aceptada.")
    }

    fun rejectSharing() {
        println("Conexión de datos rechazada.")
    }
}
