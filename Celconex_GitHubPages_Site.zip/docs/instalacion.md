# Instalación de Celconex

## Windows

1. Descarga `CelconexInstaller.exe`
2. Sigue el asistente en español
3. Crea acceso directo al escritorio (opcional)

## Linux (.deb)

```bash
sudo dpkg -i celconex_1.0_amd64.deb
```

## Linux (AppImage)

1. Descarga `Celconex-x86_64.AppImage`
2. Da permisos de ejecución
3. Ejecuta directamente

```bash
chmod +x Celconex-x86_64.AppImage
./Celconex-x86_64.AppImage
```