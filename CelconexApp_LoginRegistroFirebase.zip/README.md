# Celconex App con Login y Registro Firebase

Pantalla completa para inicio de sesión y creación de cuenta.