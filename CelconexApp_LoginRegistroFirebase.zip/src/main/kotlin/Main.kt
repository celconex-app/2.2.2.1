import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Window
import androidx.compose.ui.window.application
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth

@Composable
fun LoginRegisterScreen(auth: FirebaseAuth) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var isRegister by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier.fillMaxSize().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(if (isRegister) "Crear cuenta" else "Iniciar sesión", style = MaterialTheme.typography.h5)
        Spacer(modifier = Modifier.height(16.dp))

        OutlinedTextField(value = email, onValueChange = { email = it }, label = { Text("Email") })
        OutlinedTextField(value = password, onValueChange = { password = it }, label = { Text("Password") }, visualTransformation = PasswordVisualTransformation())
        Spacer(modifier = Modifier.height(16.dp))

        Button(onClick = {
            if (isRegister) {
                auth.createUserWithEmailAndPassword(email, password)
                    .addOnSuccessListener {
                        message = "✅ Cuenta creada e iniciada"
                    }
                    .addOnFailureListener {
                        message = "❌ Error: ${'$'}{it.message}"
                    }
            } else {
                auth.signInWithEmailAndPassword(email, password)
                    .addOnSuccessListener {
                        message = "✅ Sesión iniciada"
                    }
                    .addOnFailureListener {
                        message = "❌ Error: ${'$'}{it.message}"
                    }
            }
        }) {
            Text(if (isRegister) "Registrarse" else "Iniciar sesión")
        }

        Spacer(modifier = Modifier.height(8.dp))

        TextButton(onClick = { isRegister = !isRegister }) {
            Text(if (isRegister) "¿Ya tienes cuenta? Inicia sesión" else "¿No tienes cuenta? Regístrate")
        }

        Spacer(modifier = Modifier.height(8.dp))
        Text(message)
    }
}

fun main() = application {
    Window(onCloseRequest = ::exitApplication, title = "Celconex - Login/Registro") {
        FirebaseApp.initializeApp(null)
        val auth = remember { FirebaseAuth.getInstance() }
        MaterialTheme {
            LoginRegisterScreen(auth)
        }
    }
}