# Roadmap de Celconex

## ✅ v1.0
- Login con Firebase
- Envío de SMS de emparejamiento
- Firestore para estado de conexiones
- Instalador y documentación

## 🔜 v1.1
- Código de autorización por número
- Opción de aceptar/rechazar compartir datos

## 🔮 v2.0
- Panel web para administración
- Historial de conexiones
- Notificaciones push