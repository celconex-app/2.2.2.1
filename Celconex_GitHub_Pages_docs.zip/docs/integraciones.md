# 🔌 Integraciones de Celconex

## Usuario Firebase

- **ID**: `arturoochoa0606`

## Datos de Twilio

```json
{
  "account_sid": "ACeb9349bdc04005284aea84fbe74acfea",
  "channel": "sms",
  "date_created": "2025-07-23T09:58:29Z",
  "date_updated": "2025-07-23T09:58:57Z",
  "service_sid": "VA7446bdbe811012db652f5678d433746b",
  "sid": "VE4f0a3c5f951ff16398277ce6fca33c29",
  "status": "approved",
  "to": "+528135976157",
  "valid": true
}
```