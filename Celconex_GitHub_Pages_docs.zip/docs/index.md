# Bienvenido a Celconex

Celconex es una aplicación multiplataforma que te permite compartir tu conexión de datos móviles con otros usuarios autorizados.

### Documentación

- [📌 Roadmap](roadmap.md)
- [🔐 Integraciones (Firebase & Twilio)](integraciones.md)
- [🖥 Instalación de la aplicación](instalacion.md)