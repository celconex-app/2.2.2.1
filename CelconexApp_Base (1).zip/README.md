# Celconex App

Aplicación de escritorio Kotlin para compartir datos móviles.