# Celconex App con Login Firebase

Pantalla básica de inicio de sesión con Firebase Auth.